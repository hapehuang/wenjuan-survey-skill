/**
 * 浏览器打开等场景使用的子进程封装（仅此文件引用 child_process）。
 */

const { spawn } = require("child_process");

const OPEN_UNREF_MS = 3000;

/**
 * detached 子进程打开 URL；短时 resolve 并 unref。
 * @param {string} command
 * @param {string[]} args
 * @param {import('child_process').SpawnOptions} [extraOpts]
 */
function spawnOpenDetached(command, args, extraOpts = {}) {
  return new Promise((resolve, reject) => {
    const opts = { detached: true, stdio: "ignore", ...extraOpts };
    const child = spawn(command, args, opts);
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`浏览器打开失败，退出码: ${code}`));
      }
    });
    setTimeout(() => {
      child.unref();
      resolve();
    }, OPEN_UNREF_MS);
  });
}

/**
 * 整段 URL 作为单个参数传给子进程，避免 Windows cmd 解析 &。
 * @param {string} url
 * @returns {Promise<void>}
 */
function spawnOpenUrl(url) {
  return new Promise((resolve, reject) => {
    const platform = process.platform;
    let command;
    let args = [];
    const opts = { detached: true, stdio: "ignore" };

    switch (platform) {
      case "darwin":
        command = "open";
        args = [url];
        break;
      case "linux":
        command = "xdg-open";
        args = [url];
        break;
      case "win32":
        command = "rundll32";
        args = ["url.dll,FileProtocolHandler", url];
        opts.windowsHide = true;
        break;
      default:
        reject(new Error(`不支持的操作系统: ${platform}`));
        return;
    }

    const child = spawn(command, args, opts);
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`浏览器打开失败，退出码: ${code}`));
      }
    });
    setTimeout(() => {
      child.unref();
      resolve();
    }, OPEN_UNREF_MS);
  });
}

module.exports = {
  spawnOpenDetached,
  spawnOpenUrl,
};
